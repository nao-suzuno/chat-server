# chat-server
サーバーサイド

- Go 1.18.10
- OpenAI API gpt-3.5-turbo

[フロントエンド (repository)](https://github.com/nao-suzuno/chat-front)
# インフラ構成図

![image](image/infra.png)
